package fr.upmfgrenoble.wicproject;

/**
 * Created by thibaud on 06/11/15.
 */
public class Utils {

    public static String LOG_TAG = "wic-project";

}
